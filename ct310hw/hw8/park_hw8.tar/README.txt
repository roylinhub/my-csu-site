http://www.cs.colostate.edu/~park/hw8/hw8.php


Fill in the form and press add to add an animal and its properties.
Trying to add an animal when it already exists will not insert.
Trying to add an animal when there are 50 rows will not insert.
Images are set to 50x50 for sanity's sake.
