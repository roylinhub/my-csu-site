<?php
$exNumText = '01';
include 'ct310phpexStart.php';
?>
</head>
<?php include 'ct310phpexHeader.php';?>
<div id="contents">
<p>
This is about the simplest JavaScript example possible. 
View the source to see what is going on.
</p>
<script type="text/javascript">
   document.write("<p>Hello World</p>");
</script>
<noscript>
<p>Your browser doesn't support or has disabled JavaScript.</p>
</noscript>
</div>
<!--  end of the page contents -->

<?php
echo "</div> <!-- The end of the page diviion -->\n";
echo "</body>\n</html>\n";
?>