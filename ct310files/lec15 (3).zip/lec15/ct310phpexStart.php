<?php  
echo '<?xml version="1.0" encoding="utf-8"?>'."\n" ; 
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"'."\n"; 
echo '         "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';

echo '<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">'."\n";
echo "<head>\n";
$heading = "CT 310 PHP Lec 15 Example $exNumText";
echo "<title> $heading </title>\n" 
?>
   <link href="ct310phpex.css" rel="stylesheet" type="text/css" />
   <meta http-equiv="Content-Type" 
         content="text/html; charset=utf-8" />
