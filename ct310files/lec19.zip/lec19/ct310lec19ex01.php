<?php
$exNumText = '01';
include 'ct310lec19Start.php';
?>
<link href="spinny5.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="spinny5.js"></script>
<script type="text/javascript">
	window.onload = init;
</script>
</head>
<?php include 'ct310lec19Header.php';?>
<div id="contents">
<h2 style="margin-left:auto;margin-right:auto">Spinny in JavaScript and HTML5.</h2>
<p>
This is an example of using timed events to set an animation in motion.
</p>
<canvas id="stones" width="300" height="300"></canvas>
</div>
<!--  end of the page contents -->
<?php
echo "</div> <!-- The end of the page diviion -->\n";
echo "</body>\n</html>\n";
?>