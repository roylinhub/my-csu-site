<!-- Start of page Body -->
<body>
<?php 
    echo "<div id=\"page\">\n";
    echo "<div id=\"header\"> $heading </div>\n";
?>