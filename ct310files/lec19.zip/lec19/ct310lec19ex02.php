<?php
$exNumText = '02';
include 'ct310lec19Start.php';
?>
</head>
<?php include 'ct310lec19Header.php';?>
<div id="contents">
	<h2 style="margin-left: auto; margin-right: auto">Displaying video in
		HTML 5.</h2>

	<p> Displaying embedded video has become much easier in HTML 5. Below is a
		19 second clip from a <a href='http://archive.org/details/oi55297'>video of
		the German airship Graf Zeppelin flying over the Netherlands.</a>
	</p>
	<video width=640 height=480 controls="controls">
		<source src="./HRE00016A39clip19secs.webm" type="video/webm">
		<source src="./HRE00016A39clip19secs.mp4" type="video/mp4">
		Your browser does not support the video tag.
	</video>
</div>
<!--  end of the page contents -->

<?php
echo "</div> <!-- The end of the page diviion -->\n";
echo "</body>\n</html>\n";
?>