<?php 
$pgTitle = "CT 310 Lecture 19 Examples";
include('../../config.php');
include('../../ztools/common_allfuns.php');
include('../../ztools/common_headstart.php');
?>   
   <link href="../../styles.css" rel="stylesheet" type="text/css" /> 
</head>
<?php 
   $pgLevel = 2;
   include('../../ztools/common_navigation.php');
?>
<!-- Start contents of main page here. -->
<div id="contents">

<p>Here are the examples used in Lecture 19 in HTML 5.</p>

<ul>
    <li><a href="ct310lec19ex01.php">Example 1:  Timed events and animation, meet Spinny in HTML 5.</a></li>
    <li><a href="ct310lec19ex02.php">Example 2:  Embedding video has grown much easier.</a></li>
</ul>

<p>Here is a file you may download with the actual php content: <a href="lec19.zip">lec19.zip </a></p>

</div>
<!-- End of contents -->
<?php include('../../ztools/common_terminate.php'); ?>
