var i, dots, row, col;
var stones; // This will be the Canvas displaying image and spinny
var contxt; // The drawin context of the Canvas
var radius = 64;
var dotr   = 10;
var theta = 0.0;
var delta = Math.PI / 8;
var voff = 150;
var hoff = 150;

function drawDot(xpos, ypos, alpha) {
	contxt.beginPath();
	contxt.globalAlpha = alpha;
	contxt.arc(xpos, ypos, dotr, 0, 2 * Math.PI, false);
	contxt.fillStyle = '#ff3f04';
	contxt.fill();
	contxt.strokeStyle = '#ff3f04';;
	contxt.lineWidth = 2;
	contxt.stroke();
}

function placeDots() {
	contxt.clearRect(0, 0, stones.width, stones.height);
	for (i = 0; i < 10; i++) {
		row = voff + (radius * Math.cos(theta + (i * delta)));
		col = hoff + (radius * Math.sin(theta + (i * delta)));
		drawDot(row, col, (1.0 - i/10));
	}
}

function init() {
	stones = document.getElementById("stones");
	contxt = stones.getContext('2d');
	placeDots();
	setTimeout(doStep, 100);
}

function doStep() {
	theta = theta - delta;
	placeDots();
	setTimeout(doStep, 100);
}