
<div style="float:right; width=auto;text-align:right; padding:5px; border:thin; border-color:#000000; background-color:#FFFFCC; border-style: solid;margin-left:16px;">
   <a href="musicTakeTwoP0Top.php">Music Take Two Home</a><br/>
   <a href="musicTakeTwoP1Create.php">Create New Music Database</a><br/>
   <a href="musicTakeTwoP2Destroy.php">Destroy Music Database</a><br/>
   <a href="musicTakeTwoP3View.php">View Music Database</a><br/>
   <a href="musicTakeTwoP4ViewBy.php">View Muisc Sorted</a><br/>
   <a href="musicTakeTwoP5Add.php">Add to the Music</a><br/>
   <a href="musicTakeTwoP6Find.php">Find a CD</a><br/>
   <a href="musicTakeTwoP7Remove.php">Remove a CD</a><br/>
   <a href="musicTakeTwoP8Inject.php">Play with Injection</a><br/>
   <a href="musicTakeTwo.zip">Zip file with all PHP code</a><br/>
</div>
