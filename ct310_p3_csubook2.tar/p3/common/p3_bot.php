
			</div> <!--end main_container-->
	<div class="clear"></div>	
</div><!--main_wrapper-->
</body>
</html>
